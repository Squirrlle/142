#include "FileViewer.h"

int main() {
	FileViewer viewer;
	viewer.run();

	return 0;
}
